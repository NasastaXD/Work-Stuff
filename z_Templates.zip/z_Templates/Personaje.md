---
descripción: Epico Papu
Título:
Alias:
Raza:
Muerte:
Afiliación:
Grupo:
Histórico: false
NoteIcon: npc
Gracia:
Dominio: 
Familia:
fc-calendar: Calendario
fc-date:
aat-render-enabled: false
timelines:
  - cronología magna
fc-event-body: Nacimiento del personaje.
---

> [!infobox]
> # `=this.file.name`
> # <font size=3>*`=this["descripción"]`*</font>
> ![[IMG_7169.jpeg]]
> ###### Información Básica
> Campo |  Valor |
> ---|---|
> Título | `=this["Título"]` |
> Alias | `=this["Alias"]` |
> Raza | `=this["Raza"]` |
> Nacimiento | `=this["fc-date"]` |
> Muerte | `=this["Muerte"]` |
> Afiliación | `=this["Afiliación"]` |
> ###### [[Hierométrica]]
> Campo |  Valor |
> ---|---|
> Sistema | `=this["Sistema"]` | Si
> Afinidad | `=this["Afinidad"]` |

# `=this.file.name`

## Apariencia y Carácter

## Cualificaciones

## Historia

## Citas

## Gracia & Stuff