---
Nombre:
Ubicación:
fc-calendar: Calendario
fc-date:
aat-render-enabled: false
timelines:
  - cronología magna
fc-event-body: Batalla de ejemplo.


# `=this.file.name`

## Campo de Batalla y Condiciones

## Preludio y Despliegue

## Enfrentamiento

## Desenlace

## Consecuencias

## Legado

## Notas
